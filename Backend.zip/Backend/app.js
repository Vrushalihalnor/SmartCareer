const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();

// ✅ Import route files
const registerRoutes = require("./Register"); // Registration API
const loginRoutes = require("./Login");       // Login API
const studentInterestsRoutes = require("./subject"); // GET interests API

// ✅ Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// ✅ Mount routes
app.use("/api", registerRoutes);          // POST /api/register
app.use("/api", loginRoutes);             // POST /api/login
app.use("/api", studentInterestsRoutes);  // GET /api/student-interests

// ✅ Root route for sanity check
app.get("/", (req, res) => {
  res.send("Server is running. Use /api endpoints for operations.");
});

// ✅ Start server
const PORT = process.env.PORT || 3300;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
