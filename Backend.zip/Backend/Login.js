// Login.js
const express = require("express");
const router = express.Router();
const mysql = require("mysql2");
const bcrypt = require("bcryptjs");

// ✅ Use connection pool
const db = mysql.createPool({
  host: "195.35.45.44",
  user: "root",
  password: "vikram123",
  database: "DGExpo",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

console.log("✅ MySQL pool created for Login");

// POST /api/login
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password)
    return res.status(400).json({ error: "Please provide email and password" });

  const query = "SELECT * FROM users WHERE email = ?";

  db.query(query, [email], async (err, results) => {
    if (err) {
      console.error("DB Error:", err);
      return res.status(500).json({ error: "Database error" });
    }

    if (results.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }

    const user = results[0];

    try {
      const match = await bcrypt.compare(password, user.password);
      if (!match) {
        return res.status(401).json({ error: "Incorrect password" });
      }

      res.json({
        message: "Login successful ✅",
        user: {
          id: user.user_id, // ensure this matches your DB schema
          name: user.name,
          email: user.email,
        },
      });
    } catch (err) {
      console.error("Error during password comparison:", err);
      res.status(500).json({ error: "Server error" });
    }
  });
});

module.exports = router;
