const express = require("express");
const router = express.Router();
const mysql = require("mysql2");
const bcrypt = require("bcryptjs");

// MySQL connection
const db = mysql.createConnection({
   host: "195.35.45.44",
    user: "root",
    password: "vikram123",
  database: "DGExpo"
});

db.connect((err) => {
  if (err) console.error("❌ MySQL Connection Error:", err);
  else console.log("✅ Connected to MySQL");
});

// POST /api/register
router.post("/register", async (req, res) => {
  const { name, email, std, password, dob, interest1, interest2, interest3, age_group } = req.body;

  if (!name || !email || !password)
    return res.status(400).json({ error: "Name, email, and password are required" });

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const sql = `INSERT INTO users (name, email, std, password, dob, interest1, interest2, interest3, age_group)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    db.query(sql, [name, email, std, hashedPassword, dob, interest1, interest2, interest3, age_group],
      (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "User registered successfully!", user_id: result.insertId });
      });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
